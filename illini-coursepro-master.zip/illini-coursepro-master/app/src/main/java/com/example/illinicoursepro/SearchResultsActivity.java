package com.example.illinicoursepro;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class SearchResultsActivity extends AppCompatActivity {

    TextView courseName;
    TextView courseNumber;
    TextView courseDescription;
    Button viewSections;
    ImageButton homeButton;
    ImageButton backButton;

    String[] searchedCourse;

    String coursename;
    String coursesubject;
    String coursenumber;

    private SQLiteDatabase db;
    private DataStore myDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);
        myDBHelper = new DataStore(this);
        db = myDBHelper.getReadableDatabase();

        // Retrieve elements from layout file
        courseName = findViewById(R.id.courseName);
        courseNumber = findViewById(R.id.courseNumber);
        courseDescription = findViewById(R.id.description);
        viewSections = (Button) findViewById(R.id.viewSections);

        // Retrieve packaged intent information
        Intent courseIntent = getIntent();
        Bundle bundle = courseIntent.getExtras();

        if (bundle != null) {
            searchedCourse = (String[]) bundle.get("Course");
        }

        // Populate the course info on the screen
        if (searchedCourse.length == 2) {
            coursesubject = searchedCourse[1].split(" ")[0];
            coursenumber = searchedCourse[1].split(" ")[1];
            coursename = searchedCourse[0];
            courseName.setText(searchedCourse[0]);
            courseNumber.setText(searchedCourse[1]);
            Cursor cursor = db.query(true,"courses",new String[]{"Description"},"CourseName=?",new String[]{searchedCourse[0]},null,null,null,null);
            if (cursor.moveToFirst()) {
                @SuppressLint("Range") String cdes = cursor.getString(cursor.getColumnIndex("Description"));
                courseDescription.setText(cdes);
            }
            cursor.close();
        } else if (searchedCourse.length == 1) {
            coursesubject = searchedCourse[0].split(" ")[0];
            coursenumber = searchedCourse[0].split(" ")[1];
            courseNumber.setText(searchedCourse[0]);
            String[] course = searchedCourse[0].split(" ");
            Cursor cursor = db.query(true,"courses",new String[]{"Description","CourseName"},"Subject=? and Number=?",new String[]{course[0],course[1]},null,null,null,null);
            if (cursor.moveToFirst()) {
                @SuppressLint("Range") String cdes = cursor.getString(cursor.getColumnIndex("Description"));
                @SuppressLint("Range") String cname = cursor.getString(cursor.getColumnIndex("CourseName"));
                courseDescription.setText(cdes);
                courseName.setText(cname);
                coursename = cname;
            }
            cursor.close();
        }

        // Create onClick callback for the "View Sections" button
        viewSections.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String [] selectcourse = {coursename,coursesubject,coursenumber};
                Intent intent = new Intent(SearchResultsActivity.this, CourseSectionsActivity.class);
                intent.putExtra("Course", selectcourse);
                startActivity(intent);
            }
        });

        // Home button code
        homeButton = findViewById(R.id.home);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SearchResultsActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        // Back button code
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}