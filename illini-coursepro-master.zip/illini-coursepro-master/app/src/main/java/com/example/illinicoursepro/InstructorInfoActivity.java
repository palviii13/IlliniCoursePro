package com.example.illinicoursepro;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.database.Cursor;

public class InstructorInfoActivity extends AppCompatActivity {

    ImageButton homeButton;
    ImageButton backButton;
    TextView courseName;
    TextView courseNumber;
    Button seeReviews;
    Button postReviews;

    String[] searchedCourse = {};
    String[] setFilters = {};
    String[] course;
    String passCourseId;
    String passInsName;
    String passCourseSubNum;
    private SQLiteDatabase db;
    private DataStore myDBHelper;
    double takeCount;
    double gradeAmount;
    Integer aCount = 0;
    Integer bCount = 0;
    Integer cCount = 0;
    Integer dCount = 0;
    Integer fCount = 0;
    String currentEmail;
    String currentSubNum;
    String currentRating;
    Integer positiveReview = 0;
    Integer negativeReview = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor_info);
        Intent searchedIntent = getIntent();
        Bundle bundle = searchedIntent.getExtras();
        myDBHelper = new DataStore(this);
        db = myDBHelper.getReadableDatabase();

        if (bundle != null) {
            course = (String[]) bundle.get("passList");
        }
        passCourseId = course[0];
        passInsName = course[1];
        Cursor cursor = db.query(true,
                "courses",
                null,
                "CourseId=?",
                new String[]{passCourseId},
                null,
                null,
                null,
                null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                @SuppressLint("Range") String curEmail = cursor.getString(cursor.getColumnIndex("Email"));
                currentEmail = curEmail;
                @SuppressLint("Range") String curSubject = cursor.getString(cursor.getColumnIndex("Subject"));
                @SuppressLint("Range") String curNumber = cursor.getString(cursor.getColumnIndex("Number"));
                currentSubNum = curSubject + " " + curNumber;
                @SuppressLint("Range") String curRating = cursor.getString(cursor.getColumnIndex("Rating"));
                currentRating = curRating;

                @SuppressLint("Range") Integer curAplus = cursor.getInt(cursor.getColumnIndex("A+"));
                @SuppressLint("Range") Integer curAmid = cursor.getInt(cursor.getColumnIndex("A"));
                @SuppressLint("Range") Integer curAminus = cursor.getInt(cursor.getColumnIndex("A-"));
                aCount = curAplus + curAmid + curAminus;
                @SuppressLint("Range") Integer curBplus = cursor.getInt(cursor.getColumnIndex("B+"));
                @SuppressLint("Range") Integer curBmid = cursor.getInt(cursor.getColumnIndex("B"));
                @SuppressLint("Range") Integer curBminus = cursor.getInt(cursor.getColumnIndex("B-"));
                bCount = curBplus + curBmid + curBminus;

                @SuppressLint("Range") Integer curCplus = cursor.getInt(cursor.getColumnIndex("C+"));
                @SuppressLint("Range") Integer curCmid = cursor.getInt(cursor.getColumnIndex("C"));
                @SuppressLint("Range") Integer curCminus = cursor.getInt(cursor.getColumnIndex("C-"));
                cCount = curCplus + curCmid + curCminus;

                @SuppressLint("Range") Integer curDplus = cursor.getInt(cursor.getColumnIndex("D+"));
                @SuppressLint("Range") Integer curDmid = cursor.getInt(cursor.getColumnIndex("D"));
                @SuppressLint("Range") Integer curDminus = cursor.getInt(cursor.getColumnIndex("D-"));
                dCount = curDplus + curDmid + curDminus;

                @SuppressLint("Range") Integer curFmid = cursor.getInt(cursor.getColumnIndex("F"));
                fCount = curFmid;

                takeCount = curAplus + curAmid + curAminus +
                            curBplus + curBmid + curBminus +
                            curCplus + curCmid + curCminus +
                            curDplus + curDmid + curDminus +
                            curFmid;
                gradeAmount = curAplus*4 + curAmid*4 + curAminus*3.67 +
                        curBplus*3.33 + curBmid*3 + curBminus*2.67 +
                        curCplus*2.33 + curCmid*2 + curCminus*1.67 +
                        curDplus*1.33 + curDmid*1 + curDminus*0.67;
            }
        }
        cursor.close();
        double avgGPA = gradeAmount/takeCount;
        double roundGPA = Math.round(avgGPA*100)/100.00;
        // Get the elements in the layout file
        // Populate course number and name info from previous screens
        TextView titleView = findViewById(R.id.courseNumber);
        titleView.setText(currentSubNum);

        TextView insNameView = findViewById(R.id.courseInstructor);
        insNameView.setText("Instructor: " + passInsName);

        TextView insEmailView = findViewById(R.id.instructorEmail);
        insEmailView.setText("Email: " + currentEmail);

        TextView gpaView = findViewById(R.id.avgGPAView);
        gpaView.setText("Average GPA: " + roundGPA);

        GradeBarView gradeBar = findViewById(R.id.gradeBar);
        gradeBar.setValues(aCount, bCount, cCount, dCount, fCount);

        RatingBar ratingBar = findViewById(R.id.ratingBar);
        ratingBar.setRating(Float.parseFloat(currentRating));

        TextView ratingNumView = findViewById(R.id.ratingNumber);
        ratingNumView.setText(currentRating);
//        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
//            @Override
//            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
//                // Handle the rating change here
//                // You can use the "rating" variable to get the selected rating value
//                // For example, display a toast message with the selected rating
//                Toast.makeText(InstructorInfoActivity.this, "Rating: " + rating, Toast.LENGTH_SHORT).show();
//            }
//        });

        Cursor cursor2 = db.query(
                "reviews",
                new String[] {"reflection"},
                "CourseId=?",
                new String[]{passCourseId},
                null,
                null,
                null,
                null);
        if (cursor2 != null) {
            while(cursor2.moveToNext()) {
                @SuppressLint("Range") Integer curReflection = cursor2.getInt(cursor2.getColumnIndex("reflection"));
                if (curReflection == 1) {
                    positiveReview ++;
                } else {
                    negativeReview ++;
                }
            }
            cursor2.close();
        }

        TextView poView = findViewById(R.id.poReview);
        poView.setText(positiveReview + " Positive Reviews");

        TextView neView = findViewById(R.id.neReview);
        neView.setText(negativeReview + " Negative Reviews");

        // See reviews button code
        seeReviews = (Button) findViewById(R.id.seeReviewsButton);
        seeReviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InstructorInfoActivity.this, ReadReviewsActivity.class);
                intent.putExtra("passList", course);
                startActivity(intent);
            }
        });

        // Write reviews button code
        postReviews = (Button) findViewById(R.id.postReviewsButton);
        postReviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InstructorInfoActivity.this, WriteReviewActivity.class);
                intent.putExtra("passList", course);
                startActivity(intent);
            }
        });

        // Home button code
        homeButton = findViewById(R.id.home);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InstructorInfoActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        // Back button code
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}