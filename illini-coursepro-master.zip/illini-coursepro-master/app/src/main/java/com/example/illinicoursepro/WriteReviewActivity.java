package com.example.illinicoursepro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class WriteReviewActivity extends AppCompatActivity {

    ImageButton homeButton;
    ImageButton backButton;
    Button postReview;
    TextView courseNumber;
    TextView instructorName;
    Spinner majorSpinner;
    Spinner gradeSpinner;
    Spinner yearTakenSpinner;
    RatingBar reviewsRatingBar;
    RadioButton negButton;
    RadioButton posButton;
    EditText reviewContent;

    String[] course;
    String[] majorList = {"Select Major", "CS", "BADM", "MATH"};
    String[] gradeList = {"Select Grade", "A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F", "W"};
    String[] yearTakenList = {"Select Year Taken", "2023", "2022", "2021", "2020", "2019"};

    ContentValues reviews;
    private DataStore myDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_review);
        myDBHelper = new DataStore(this);

        // Get the elements in the layout file
        courseNumber = findViewById(R.id.courseNumber);
        instructorName = findViewById(R.id.courseInstructor);

        // Populate course number and instructor info from previous screens
        Intent searchedIntent = getIntent();
        Bundle bundle = searchedIntent.getExtras();

        if (bundle != null) {
            course = (String[]) bundle.get("passList");
        }

        // Populate the text on the screen
        if (course.length == 3) {
            courseNumber.setText(course[2]);
            instructorName.setText(course[1]);
        }

        // Populate the spinners
        majorSpinner = findViewById(R.id.majorSpinner);
        ArrayAdapter<String> majorAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, majorList);
        majorSpinner.setAdapter(majorAdapter);

        gradeSpinner = findViewById(R.id.gradeSpinner);
        ArrayAdapter<String> gradeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, gradeList);
        gradeSpinner.setAdapter(gradeAdapter);

        yearTakenSpinner = findViewById(R.id.yearSpinner);
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, yearTakenList);
        yearTakenSpinner.setAdapter(yearAdapter);

        reviewsRatingBar = findViewById(R.id.reviewsRatingBar);

        negButton = findViewById(R.id.negativeRadioButton);
        posButton = findViewById(R.id.positiveRadioButton);

        reviewContent = findViewById(R.id.typeReviewsEditText);

        // Post review button code
        postReview = findViewById(R.id.postReviewButton);
        postReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WriteReviewActivity.this, ReadReviewsActivity.class);
                reviews = new ContentValues();
                reviews.put("userId", "twentysixCarter");
                reviews.put("major", majorSpinner.getSelectedItem().toString());
                reviews.put("CourseId", course[0]);
                reviews.put("grade", gradeSpinner.getSelectedItem().toString());
                reviews.put("rating", reviewsRatingBar.getRating());
                String reflection = "";
                if (negButton.isChecked()) {
                    reflection = "0";
                } else if (posButton.isChecked()) {
                    reflection = "1";
                }
                reviews.put("reflection", reflection);
                reviews.put("takenYear", yearTakenSpinner.getSelectedItem().toString());
                reviews.put("context", reviewContent.getText().toString());

                if (majorSpinner.getSelectedItem().toString().isEmpty()
                        || gradeSpinner.getSelectedItem().toString().isEmpty()
                        || reviewsRatingBar.getRating() == 0.0
                        || (!negButton.isChecked() && !posButton.isChecked())
                        || yearTakenSpinner.getSelectedItem().toString().isEmpty()
                        || reviewContent.getText().toString().isEmpty()) {
                    Toast.makeText(WriteReviewActivity.this, "Please fill out all options!", Toast.LENGTH_SHORT).show();
                } else {
                    boolean result = false;
                    result = myDBHelper.insertReviewsToDB(reviews);
                    if (result) {
                        Toast.makeText(WriteReviewActivity.this, "Review posted successfully!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(WriteReviewActivity.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
                    }
                    startActivity(intent);
                }
            }
        });

        // Home button code
        homeButton = findViewById(R.id.home);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WriteReviewActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        // Back button code
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}