package com.example.illinicoursepro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    Button nextButton;
    private DataStore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.deleteDatabase("university.db"); // delete the database file each time you run the app
        Log.d("TestLog", "onCreate executed");

        db = new DataStore(this);

        // Importing the CSV file should be done in a separate thread to avoid freezing the UI
        new Thread(() -> {
            try {
                db.importCoursesFromCSV("465CrDB.csv");
                db.importUsersFromCSV("465UsDB.csv");
                db.importReviewsFromCSV("465ReDB.csv");
            } catch (IOException e) {
                e.printStackTrace(); // Handle exception properly in production code
            }
        }).start();

        nextButton = (Button) findViewById(R.id.nextButton);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onDestroy() {
        db.close(); // Close the database helper when the activity is destroyed
        super.onDestroy();
    }

}