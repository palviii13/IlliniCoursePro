package com.example.illinicoursepro;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.InputStreamReader;

import android.content.ContentValues;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import androidx.annotation.Nullable;

public class DataStore extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "university.db";
    private static int DATABASE_VERSION = 12;

    // Table Names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_COURSES = "courses";
    private static final String TABLE_REVIEWS = "reviews";

    // ************* Users Table columns
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_PASSWORD = "password";

    // ************* Courses Table columns
    private static final String KEY_YEAR = "Year";
    private static final String KEY_TERM = "Term";
    private static final String KEY_YEAR_TERM = "YearTerm";
    private static final String KEY_SUBJECT = "Subject";
    private static final String KEY_NUMBER = "Number";

    private static final String KEY_COURSEID = "CourseId";
    private static final String KEY_COURSE_TITLE = "CourseName";

    private static final String KEY_DESCRIPTION = "Description";
    private static final String KEY_SCHED_TYPE = "SchedType";
    // Columns for grades
    private static final String KEY_INSTRUCTOR_NAME = "instructorName";
    private static final String KEY_TIME = "Time";
    private static final String KEY_LOCATION = "Location";
    private static final String KEY_EMAIL = "Email";
    private static final String KEY_RATING = "Rating";


    // ... other course columns ...

    // *************  Reviews Table columns
    private static final String KEY_CONTEXT = "context";
    private static final String KEY_MAJOR = "major";
    // ... other review columns ...

    // SQL CREATE TABLE STATEMENTS

    // User Table Create Statement
    private static final String CREATE_TABLE_USERS = "CREATE TABLE "
            + TABLE_USERS + "("
            + KEY_USER_ID + " TEXT PRIMARY KEY,"
            + KEY_PASSWORD + " TEXT"
            + ")";

    // Course Table Create Statement
    private static final String CREATE_TABLE_COURSES = "CREATE TABLE " + TABLE_COURSES + "("
            + KEY_COURSEID + " INTEGER PRIMARY KEY,"
            + KEY_COURSE_TITLE + " TEXT,"
            + KEY_YEAR + " INTEGER,"
            + KEY_TERM + " TEXT,"
            + KEY_SUBJECT + " TEXT,"
            + KEY_NUMBER + " INTEGER,"
            + KEY_DESCRIPTION + " TEXT,"
            + KEY_TIME + " TEXT,"
            + KEY_LOCATION + " TEXT,"
            + KEY_INSTRUCTOR_NAME + " TEXT,"
            + KEY_EMAIL + " TEXT,"
            + "\"A+\" INTEGER," // Enclose the column name in double quotes
            + "\"A\" INTEGER,"
            + "\"A-\" INTEGER,"
            + "\"B+\" INTEGER,"
            + "\"B\" INTEGER,"
            + "\"B-\" INTEGER,"
            + "\"C+\" INTEGER,"
            + "\"C\" INTEGER,"
            + "\"C-\" INTEGER,"
            + "\"D+\" INTEGER,"
            + "\"D\" INTEGER,"
            + "\"D-\" INTEGER,"
            + "\"F\" INTEGER,"
            + "\"W\" INTEGER,"
            + KEY_RATING + " REAL"
            + ")";


    // Review Table Create Statement
    private static final String CREATE_TABLE_REVIEWS = "CREATE TABLE "
            + TABLE_REVIEWS + "("
            + "reviewId INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_USER_ID + " TEXT,"
            + KEY_COURSEID + " TEXT,"
            + KEY_CONTEXT + " TEXT,"
            + KEY_MAJOR + " TEXT,"
            + "grade TEXT,"
            + "takenYear INTEGER,"
            + "reflection INTEGER,"
            + "rating REAL,"
            + "FOREIGN KEY(" + KEY_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + KEY_USER_ID + "),"
            + "FOREIGN KEY(" + KEY_COURSEID + ") REFERENCES " + TABLE_COURSES + "(" + KEY_COURSEID + ")"
            + ")";

    private final Context myContext; // Member variable to hold the context


    public DataStore(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION + 1);
        this.myContext = context; // Store the context for later use
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creating required tables
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_COURSES);
        db.execSQL(CREATE_TABLE_REVIEWS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REVIEWS);

        // Create new tables
        onCreate(db);
    }

    public void importCoursesFromCSV(String csvFileName) throws IOException {
        SQLiteDatabase db = this.getWritableDatabase();

        try (InputStream is = myContext.getAssets().open(csvFileName);
             CSVReader csvReader = new CSVReader(new InputStreamReader(is))) {

            String line;
            db.beginTransaction();
            try {
                // Skip the header row if your CSV has one
                csvReader.readNext();
                String[] columns;
                while ((columns = csvReader.readNext()) != null) {
                    ContentValues cv = new ContentValues();
                    cv.put(KEY_COURSEID, columns[0].trim());
                    cv.put(KEY_COURSE_TITLE, columns[1].trim());
                    cv.put(KEY_YEAR, columns[2].trim());
                    cv.put(KEY_TERM, columns[3].trim());
                    cv.put(KEY_SUBJECT, columns[4].trim());
                    cv.put(KEY_NUMBER, columns[5].trim());
                    cv.put(KEY_DESCRIPTION, columns[6].trim());
                    cv.put(KEY_TIME, columns[7].trim());
                    cv.put(KEY_LOCATION, columns[8].trim());
                    cv.put(KEY_INSTRUCTOR_NAME, columns[9].trim());
                    cv.put(KEY_EMAIL, columns[10].trim());

                    cv.put("\"A+\"", columns[11].trim());
                    cv.put("A", columns[12].trim());
                    cv.put("\"A-\"", columns[13].trim());
                    cv.put("\"B+\"", columns[14].trim());
                    cv.put("B", columns[15].trim());
                    cv.put("\"B-\"", columns[16].trim());
                    cv.put("\"C+\"", columns[17].trim());
                    cv.put("C", columns[18].trim());
                    cv.put("\"C-\"", columns[19].trim());
                    cv.put("\"D+\"", columns[20].trim());
                    cv.put("D", columns[21].trim());
                    cv.put("\"D-\"", columns[22].trim());
                    cv.put("F", columns[23].trim());
                    cv.put("W", columns[24].trim());
                    cv.put(KEY_RATING, columns[25].trim());

                    // Continue for the rest of your columns...
                    // Ensure that the order of the columns matches the order in your CSV file

                    db.insertWithOnConflict(TABLE_COURSES, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
                db.setTransactionSuccessful();
            } catch (CsvValidationException e) {
                throw new RuntimeException(e);
            } finally {
                db.endTransaction();
            }
        } catch (IOException e) {
            // Handle exception
            Log.e("DatabaseHelper", "Error importing CSV", e);
        }
    }

    public void importReviewsFromCSV(String csvFileName) throws IOException {
        SQLiteDatabase db = this.getWritableDatabase();

        try (InputStream is = myContext.getAssets().open(csvFileName);
             CSVReader csvReader = new CSVReader(new InputStreamReader(is))) {

            String line;
            db.beginTransaction();
            try {
                // Skip the header row if your CSV has one
                csvReader.readNext();
                String[] columns;

                while ((columns = csvReader.readNext()) != null) {

                    ContentValues cv = new ContentValues();
                    cv.put(KEY_USER_ID, columns[0].trim());
                    cv.put(KEY_COURSEID, columns[1].trim());
                    cv.put(KEY_CONTEXT, columns[2].trim());
                    cv.put(KEY_MAJOR, columns[3].trim());
                    cv.put("grade", columns[4].trim());
                    cv.put("takenYear", columns[5].trim());
                    cv.put("reflection", columns[6].trim());
                    cv.put("rating", columns[7].trim());

                    // Continue for the rest of your columns...
                    // Ensure that the order of the columns matches the order in your CSV file

                    db.insertWithOnConflict(TABLE_REVIEWS, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
                db.setTransactionSuccessful();
            } catch (CsvValidationException e) {
                throw new RuntimeException(e);
            } finally {
                db.endTransaction();
            }
        } catch (IOException e) {
            // Handle exception
            Log.e("DatabaseHelper", "Error importing CSV", e);
        }
    }


    public void importUsersFromCSV(String csvFileName) throws IOException {
        SQLiteDatabase db = this.getWritableDatabase();

        try (InputStream is = myContext.getAssets().open(csvFileName);
             BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {

            String line;
            db.beginTransaction();
            try {
                // Skip the header row if your CSV has one
                reader.readLine();

                while ((line = reader.readLine()) != null) {
                    String[] columns = line.split(","); // Assuming that the CSV file has no commas in the data

                    ContentValues cv = new ContentValues();
                    cv.put(KEY_USER_ID, columns[0].trim());
                    cv.put(KEY_PASSWORD, columns[1].trim());

                    // Continue for the rest of your columns...
                    // Ensure that the order of the columns matches the order in your CSV file

                    db.insertWithOnConflict(TABLE_USERS, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
                db.setTransactionSuccessful();
            } finally {
                db.endTransaction();
            }
        } catch (IOException e) {
            // Handle exception
            Log.e("DatabaseHelper", "Error importing CSV", e);
        }
    }

    // ... CRUD operations for users, courses, reviews ...
    public boolean insertReviewsToDB(ContentValues reviews) {
        SQLiteDatabase db = this.getWritableDatabase();
        long results = db.insert(TABLE_REVIEWS, null, reviews);

        if (results == -1) {
            return false;
        } else {
            return true;
        }
    }
}