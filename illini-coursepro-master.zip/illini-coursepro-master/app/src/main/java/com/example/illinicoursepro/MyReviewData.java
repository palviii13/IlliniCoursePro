package com.example.illinicoursepro;

public class MyReviewData {
    private String ratingNumber;
    private String reviewText;
    private String schoolYear;
    private String major;
    private String yearTaken;
    private Integer posNegReview;

    public MyReviewData(String ratingNumber, String reviewText, String schoolYear, String major, String yearTaken, Integer posNegReview) {
        this.ratingNumber = ratingNumber;
        this.reviewText = reviewText;
        this.schoolYear = schoolYear;
        this.major = major;
        this.yearTaken = yearTaken;
        this.posNegReview = posNegReview;
    }

    public String getRatingNumber() {
        return ratingNumber;
    }

    public void setRatingNumber(String ratingNumber) {
        this.ratingNumber = ratingNumber;
    }

    public String getReviewText() {
        return reviewText;
    }

    public void setReviewText(String reviewText) {
        this.reviewText = reviewText;
    }

    public String getSchoolYear() {
        return schoolYear;
    }

    public void setSchoolYear(String schoolYear) {
        this.schoolYear = schoolYear;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getYearTaken() {
        return yearTaken;
    }

    public void setYearTaken(String yearTaken) {
        this.yearTaken = yearTaken;
    }

    public Integer getPosNegReview() {
        return posNegReview;
    }

    public void setPosNegReview(Integer posNegReview) {
        this.posNegReview = posNegReview;
    }
}
