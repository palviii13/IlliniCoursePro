package com.example.illinicoursepro;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

public class MyReviewAdapter extends RecyclerView.Adapter<MyReviewAdapter.ViewHolder> {

    MyReviewData[] myReviewData;
    Context context;

    public MyReviewAdapter(MyReviewData[] myReviewData, ReadReviewsActivity activity) {
        this.myReviewData = myReviewData;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.review_list_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final MyReviewData myReviewDataList = myReviewData[position];
        holder.ratingNumber.setText(myReviewDataList.getRatingNumber());
        holder.reviewText.setText(myReviewDataList.getReviewText());
        holder.schoolYear.setText(myReviewDataList.getSchoolYear());
        holder.major.setText(myReviewDataList.getMajor());
        holder.yearTaken.setText(myReviewDataList.getYearTaken());
        holder.posNegIcon.setImageResource(myReviewDataList.getPosNegReview());
    }

    @Override
    public int getItemCount() {
        return myReviewData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView ratingNumber;
        TextView reviewText;
        TextView schoolYear;
        TextView major;
        TextView yearTaken;
        ImageView posNegIcon;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ratingNumber = itemView.findViewById(R.id.ratingNumber);
            reviewText = itemView.findViewById(R.id.reviewText);
            schoolYear = itemView.findViewById(R.id.schoolYear);
            major = itemView.findViewById(R.id.major);
            yearTaken = itemView.findViewById(R.id.yearTaken);
            posNegIcon = itemView.findViewById(R.id.posNegIcon);
        }
    }
}
