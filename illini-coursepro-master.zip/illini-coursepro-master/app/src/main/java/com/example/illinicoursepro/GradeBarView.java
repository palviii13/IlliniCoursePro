package com.example.illinicoursepro;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.graphics.Canvas;
public class GradeBarView extends View {
    private int valueA, valueB, valueC, valueD, valueF;
    private Paint paint = new Paint();
    private Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GradeBarView(Context context) {
        super(context);
        init();
    }

    public GradeBarView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    private void init() {
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(40);
    }

    public void setValues(int a, int b, int c, int d, int f) {
        this.valueA = a;
        this.valueB = b;
        this.valueC = c;
        this.valueD = d;
        this.valueF = f;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int total = valueA + valueB + valueC + valueD + valueF;
        int width = getWidth();
        int height = getHeight();

        if (total == 0) {
            total = 1;
        }
            int endA = width * valueA / total;
            int endB = width * (valueA + valueB) / total;
            int endC = width * (valueA + valueB + valueC) / total;
            int endD = width * (valueA + valueB + valueC + valueD) / total;
            int endF = width * (valueA + valueB + valueC + valueD + valueF) / total;

            paint.setColor(Color.parseColor("#77FF77"));
            canvas.drawRect(0, 0, endA, height, paint);

            paint.setColor(Color.parseColor("#87CEEB"));
            canvas.drawRect(endA, 0, endB, height, paint);

            paint.setColor(Color.parseColor("#FFFF77"));
            canvas.drawRect(endB, 0, endC, height, paint);

            paint.setColor(Color.parseColor("#FF7777"));
            canvas.drawRect(endC, 0, endD, height, paint);

            paint.setColor(Color.parseColor("#777777"));
            canvas.drawRect(endD, 0, endF, height, paint);

        float textHeight = textPaint.getTextSize();
        float centerY = (height + textHeight) / 2;

        if (valueA > 0) {
            canvas.drawText("A", endA / 2, centerY, textPaint);
        }
        if (valueB > 0) {
            canvas.drawText("B", (endB + endA) / 2, centerY, textPaint);
        }
        if (valueC > 0) {
            canvas.drawText("C", (endC + endB) / 2, centerY, textPaint);
        }
        if (valueD > 0) {
            canvas.drawText("D", (endD + endC) / 2, centerY, textPaint);
        }
        if (valueF > 0) {
            canvas.drawText("F", (endF + endD) / 2, centerY, textPaint);
        }
//        if (valueA > 0) {
//            float textX = (endA / 2 < 30) ? endA - 15 : endA / 2;
//            canvas.drawText("A", textX, centerY, textPaint);
//        }
//        if (valueB > 0) {
//            float textX = ((endB + endA) / 2 < endA + 30) ? endB - 15 : (endB + endA) / 2;
//            canvas.drawText("B", textX, centerY, textPaint);
//        }
//        if (valueC > 0) {
//            float textX = ((endC + endB) / 2 < endB + 30) ? endC - 15 : (endC + endB) / 2;
//            canvas.drawText("C", textX, centerY, textPaint);
//        }
//        if (valueD > 0) {
//            float textX = ((endD + endC) / 2 < endC + 30) ? endD - 15 : (endD + endC) / 2;
//            canvas.drawText("D", textX, centerY, textPaint);
//        }
//        if (valueF > 0) {
//            float textX = ((endF + endD) / 2 < endD + 30) ? endF - 15 : (endF + endD) / 2;
//            canvas.drawText("F", textX, centerY, textPaint);
//        }
    }
}