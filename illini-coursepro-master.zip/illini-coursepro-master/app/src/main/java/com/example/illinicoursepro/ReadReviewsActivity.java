package com.example.illinicoursepro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import android.os.Bundle;
import android.widget.Spinner;
import android.widget.TextView;

public class ReadReviewsActivity extends AppCompatActivity {

    ImageButton homeButton;
    ImageButton backButton;
    RecyclerView recyclerView;
    Button refreshButton;

    TextView courseNumber;
    TextView instructorName;
    Spinner majorSpinner;
    Spinner gradeSpinner;
    Spinner yearTakenSpinner;
    Spinner plusMinusSpinner;

    private SQLiteDatabase db;
    private DataStore myDBHelper;
    String[] course;

    String[] majorList = {"Select Major", "CS", "BADM", "MATH"};
    String[] gradeList = {"Select Grade", "A", "B", "C", "D"};
    String[] yearTakenList = {"Select Year Taken", "2023", "2022", "2021", "2020"};
    String[] plusMinusList = {"+ or -", "+", "-"};

    private String selectedMajor;
    private String selectedGrade;
    private String selectedYear;
    private String selectedPlusMinus;

    String[] setFilters;
    //String[] courseNames = {"Data Structures", "System Programming", "UI Design"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_reviews);
        Intent searchedIntent = getIntent();
        Bundle bundle = searchedIntent.getExtras();

        if (bundle != null) {
            course = (String[]) bundle.get("passList");
        }

        // Get the elements in the layout file
        courseNumber = findViewById(R.id.courseNumber);
        instructorName = findViewById(R.id.courseInstructor);

        // Card list code
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

//        String courseId = getIntent().getStringExtra("COURSE_ID_KEY");
        String courseId = course[0];
        String instructor = course[1];
        String courseNum = course[2];

        // Populate the text on the screen
        courseNumber.setText(courseNum);
        instructorName.setText(instructor);


        // Populate the spinners
        majorSpinner = findViewById(R.id.majorSpinner);
        ArrayAdapter<String> majorAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, majorList);
        majorSpinner.setAdapter(majorAdapter);

        gradeSpinner = findViewById(R.id.gradeSpinner);
        ArrayAdapter<String> gradeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, gradeList);
        gradeSpinner.setAdapter(gradeAdapter);

        yearTakenSpinner = findViewById(R.id.yearSpinner);
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, yearTakenList);
        yearTakenSpinner.setAdapter(yearAdapter);

        plusMinusSpinner = findViewById(R.id.plusMinusSpinner);
        ArrayAdapter<String> plusMinusAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, plusMinusList);
        plusMinusSpinner.setAdapter(plusMinusAdapter);

        // Card list code
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // reads in review data from database
        List<MyReviewData> reviews = getReviewsForCourse(courseId, selectedMajor, selectedGrade, selectedYear, selectedPlusMinus);
        MyReviewData[] myReviewData = new MyReviewData[reviews.size()];
        for(int i = 0; i < reviews.size(); i++) myReviewData[i] = reviews.get(i);

        //add comments to the review data object list
        MyReviewAdapter myReviewAdapter = new MyReviewAdapter(myReviewData, ReadReviewsActivity.this);
        recyclerView.setAdapter(myReviewAdapter);

        // Home button code
        homeButton = findViewById(R.id.home);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ReadReviewsActivity.this, SearchActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // Back button code
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(ReadReviewsActivity.this, InstructorInfoActivity.class);
//                intent.putExtra("passList", course);
//                startActivity((intent));
                finish();
            }
        });

        // refresh button code
        refreshButton = findViewById(R.id.buttonRefresh);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RefreshReviews(courseId);
            }
        });

    }

    // refresh reviews
    private void RefreshReviews(String courseId) {
        String selectedMajor = majorSpinner.getSelectedItem().toString();
        String selectedGrade = gradeSpinner.getSelectedItem().toString();
        String selectedYear = yearTakenSpinner.getSelectedItem().toString();
        String selectedPlusMinus = plusMinusSpinner.getSelectedItem().toString();

        List<MyReviewData> reviews = getReviewsForCourse(courseId, selectedMajor, selectedGrade, selectedYear, selectedPlusMinus);
        MyReviewData[] myReviewData = new MyReviewData[reviews.size()];
        for(int i = 0; i < reviews.size(); i++) myReviewData[i] = reviews.get(i);

        //add comments to the review data object list
        MyReviewAdapter myReviewAdapter = new MyReviewAdapter(myReviewData, ReadReviewsActivity.this);
        recyclerView.setAdapter(myReviewAdapter);
    }

    // get reviews from the database
    public List<MyReviewData> getReviewsForCourse(String courseId, String selectedMajor, String selectedGrade, String selectedYear, String selectedPlusMinus) {
        List<MyReviewData> reviews = new ArrayList<>();
        myDBHelper = new DataStore(this);
        db = myDBHelper.getReadableDatabase();
        String[] strings = {"FreshMan", "Sophomore", "Junior", "Senior", "Graduate Student"};
        Random random = new Random();

        String selection = "CourseId" + " = ?";

        List<String> selectionArgsList = new ArrayList<>();
        selectionArgsList.add(courseId);
//        selectionArgs = selectionArgsList.toArray(selectionArgs);

        // Add additional criteria based on spinner values
        if (selectedMajor != null && !selectedMajor.equals("Select Major")) {
            selection += " AND major = ?";
            selectionArgsList.add(selectedMajor);
        }

        if (selectedGrade != null &&!selectedGrade.equals("Select Grade")) {
            selection += " AND grade = ?";
            selectionArgsList.add(selectedGrade);
        }

        if (selectedYear != null && !selectedYear.equals("Select Year Taken")) {
            selection += " AND takenYear = ?";
            selectionArgsList.add(selectedYear);
        }

        if (selectedPlusMinus != null && !selectedPlusMinus.equals("+ or -")) {
            selection += " AND reflection = ?";
            selectionArgsList.add(selectedPlusMinus.equals("+") ? "1" : "0"); // Assuming '1' for '+' and '0' for '-'
        }

        String[] selectionArgs = selectionArgsList.toArray(new String[0]);

        Cursor cursor = db.query(
                "reviews", // Table name
                new String[]{"CourseId", "context", "major", "grade", "takenYear", "reflection", "rating"},       // Columns to return
                selection,     // Columns for the WHERE clause
                selectionArgs, // The values for the WHERE clause
                null,          // Group by
                null,          // Having
                null           // Order by
        );

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String context = cursor.getString(cursor.getColumnIndex("context"));
                @SuppressLint("Range") String major = cursor.getString(cursor.getColumnIndex("major"));
                @SuppressLint("Range") String grade = cursor.getString(cursor.getColumnIndex("grade"));
                @SuppressLint("Range") String takenYear = cursor.getString(cursor.getColumnIndex("takenYear"));
                @SuppressLint("Range") int reflection = cursor.getInt(cursor.getColumnIndex("reflection"));
                @SuppressLint("Range") String rating = cursor.getString(cursor.getColumnIndex("rating"));
                int randomIndex = random.nextInt(strings.length);
                String randomYear = strings[randomIndex];

                // Assuming Review is your data model class
                MyReviewData review = new MyReviewData(rating, context, grade, major, takenYear, (reflection == 1? R.drawable.plus: R.drawable.minus));
                reviews.add(review);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return reviews;
    }
}
