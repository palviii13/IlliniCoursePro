package com.example.illinicoursepro;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class SearchFilterResultsActivity extends AppCompatActivity {

    TextView filteredMajor;
    TextView filteredRating;
    ListView courseList;
    ArrayAdapter<String> adapter;
    ImageButton homeButton;
    ImageButton backButton;

    private SQLiteDatabase db;
    private DataStore myDBHelper;

    String[] setFilters;
    //String[] courseNames = {"Data Structures", "System Programming", "UI Design"};
    ArrayList<String> coursenames;
    //String[] courseNumbers = {"CS 225", "CS 341", "CS 465"};
    ArrayList<String> coursenumbers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_filter_results);

        //init database
        myDBHelper = new DataStore(this);
        db = myDBHelper.getReadableDatabase();

        Intent searchedIntent = getIntent();
        Bundle bundle = searchedIntent.getExtras();

        if (bundle != null) {
            setFilters = (String[]) bundle.get("Filters");
        }

        // Populate the filter boxes
        filteredMajor = findViewById(R.id.filteredMajor);
        filteredRating = findViewById(R.id.filteredRating);

        if (setFilters.length > 0) {
            filteredMajor.setText(setFilters[0]);
            filteredRating.setText(setFilters[1]);
        }
        Character ratingfilter = setFilters[1].charAt(0);

        //get all coursename for search bar
        coursenames = new ArrayList<>();
        coursenumbers = new ArrayList<>();
        //TODO：need support rating filter
        Cursor cursor = db.query(true,"courses",new String[]{"CourseName","Number"},"Subject=? and Rating >= ?",new String[]{setFilters[0], String.valueOf(ratingfilter)},null,null,"Number",null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int cnum = cursor.getInt(cursor.getColumnIndex("Number"));
                @SuppressLint("Range") String cname = cursor.getString(cursor.getColumnIndex("CourseName"));
                coursenames.add(cname);
                coursenumbers.add(setFilters[0]+" "+cnum);
            } while (cursor.moveToNext());
        }
        cursor.close();




        // Populate the list of courses
        courseList = findViewById(R.id.listView);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, coursenames) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text1 = (TextView) view.findViewById(android.R.id.text1);
                TextView text2 = (TextView) view.findViewById(android.R.id.text2);

                text1.setText(coursenames.get(position));
                text2.setText(coursenumbers.get(position));
                return view;
            }
        };
        courseList.setAdapter(adapter);

        // Create a callback for when a course is selected
        courseList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String[] selectedCourse = {coursenames.get(position), coursenumbers.get(position)};
                Intent intent = new Intent(SearchFilterResultsActivity.this, SearchResultsActivity.class);
                intent.putExtra("Course", selectedCourse);
                startActivity(intent);
            }
        });

        // Home button code
        homeButton = findViewById(R.id.home);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SearchFilterResultsActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        // Back button code
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}