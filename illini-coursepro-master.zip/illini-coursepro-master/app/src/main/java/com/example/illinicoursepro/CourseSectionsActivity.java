package com.example.illinicoursepro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.annotation.SuppressLint;
import android.database.Cursor;
import android.widget.Button;

import java.util.ArrayList;

public class CourseSectionsActivity extends AppCompatActivity {

    TextView courseName;
    TextView courseNumber;
    ListView courseSections;
    ImageButton homeButton;
    ImageButton backButton;

    String[] course;
    ArrayAdapter<String> adapter;
    ArrayList<String> instructorNames = new ArrayList<String>();
    ArrayList<String> instructorLocs = new ArrayList<String>();
    ArrayList<String> instructorCids = new ArrayList<String>();

    private SQLiteDatabase db;
    private DataStore myDBHelper;
    String courseCurName;
    String courseCurSubject;
    String courseCurNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_sections);
        myDBHelper = new DataStore(this);
        db = myDBHelper.getReadableDatabase();

        // Get the elements in the layout file
        courseName = findViewById(R.id.courseName);
        courseNumber = findViewById(R.id.courseNumber);
        courseSections = findViewById(R.id.sectionList);

        // Get the packaged information in the intent
        Intent searchedIntent = getIntent();
        Bundle bundle = searchedIntent.getExtras();

        if (bundle != null) {
            course = (String[]) bundle.get("Course");
        }

        // Populate the text on the screen
        if (course.length == 3) {
            courseName.setText(course[0]);
            courseNumber.setText(course[1]+" "+course[2]);
        }

        courseCurName = course[0];
        courseCurSubject = course[1];
        courseCurNumber = course[2];
        Cursor cursor = db.query(true,
                "courses",
                new String[]{"instructorName", "Location", "Time", "CourseId"},
                "CourseName=? AND Subject=? AND Number=?",
                new String[]{courseCurName, courseCurSubject, courseCurNumber},
                null,
                null,
                null,
                null);
        if (cursor != null) {
            while(cursor.moveToNext()) {
                @SuppressLint("Range") String curInsName = cursor.getString(cursor.getColumnIndex("instructorName"));
                @SuppressLint("Range") String curLocation = cursor.getString(cursor.getColumnIndex("Location"));
                @SuppressLint("Range") String curTime = cursor.getString(cursor.getColumnIndex("Time"));
                @SuppressLint("Range") String curCourseId = cursor.getString(cursor.getColumnIndex("CourseId"));
                String curLoTi = curLocation + "/" + curTime;
                instructorNames.add(curInsName);
                instructorLocs.add(curLoTi);
                instructorCids.add(curCourseId);
            }
            cursor.close();
        }
        // Populate the list of instructors
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, instructorNames) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text1 = (TextView) view.findViewById(android.R.id.text1);
                TextView text2 = (TextView) view.findViewById(android.R.id.text2);

                text1.setText(instructorNames.get(position));
                text2.setText(instructorLocs.get(position));
                return view;
            }
        };
        courseSections.setAdapter(adapter);

        // Create a callback for when a course is selected
        courseSections.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(CourseSectionsActivity.this, InstructorInfoActivity.class);
                String[] passList = {instructorCids.get(position), instructorNames.get(position), courseCurSubject+" "+courseCurNumber};
                intent.putExtra("passList", passList);
                startActivity(intent);
            }
        });

        // Home button code
        homeButton = findViewById(R.id.home);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CourseSectionsActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        // Back button code
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}