package com.example.illinicoursepro;

import static java.security.AccessController.getContext;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class SearchActivity extends AppCompatActivity {

    SearchView searchView;
    ListView listView;
    Spinner majorSpinner;
    Spinner ratingSpinner;
    Button submitButton;

    private SQLiteDatabase db;
    private DataStore myDBHelper;

    ArrayList<String> coursenames;
    ArrayAdapter<String> adapter;

    ArrayList<String> majors;
    String selectedMajor = "";
    String[] ratings = {"1 star and above", "2 stars and above", "3 stars and above", "4 stars and above", "5 stars and above"};
    String selectedRating = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        //init database
        myDBHelper = new DataStore(this);
        db = myDBHelper.getReadableDatabase();

        //get all coursename for search bar
        coursenames = new ArrayList<>();
        majors = new ArrayList<>();
        SortedSet<String> csubs = new TreeSet<>();
        //Cursor cursor = db.query(true,"courses", new String[]{"Number", "Subject"},null,null,null,null,null);
        Cursor cursor = db.query(true,"courses",new String[]{"Number","Subject"},null,null,null,null,null,null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int cnum = cursor.getInt(cursor.getColumnIndex("Number"));
                @SuppressLint("Range") String csub = cursor.getString(cursor.getColumnIndex("Subject"));
                //Log.d("SearchActivity", "course is "+csub+" "+cnum);
                coursenames.add(csub+" "+cnum);
                csubs.add(csub);
            } while (cursor.moveToNext());
        }
        cursor.close();
        majors.addAll(csubs);

        searchView = findViewById(R.id.searchView);
        listView = findViewById(R.id.listView);
        majorSpinner = (Spinner) findViewById(R.id.majorSpinner);
        ratingSpinner = (Spinner) findViewById(R.id.ratingSpinner);
        submitButton = (Button) findViewById(R.id.submitButton);

        listView.setVisibility(View.GONE);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, coursenames);
        listView.setAdapter(adapter);

        // TODO: Create a callback for when a course is selected
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String[] selectedCourse = {(String) adapterView.getItemAtPosition(position)};
                Intent intent = new Intent(SearchActivity.this, SearchResultsActivity.class);
                Log.d("SearchActivity", String.valueOf(selectedCourse));

                intent.putExtra("Course", selectedCourse);
                startActivity(intent);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                listView.setVisibility(View.VISIBLE);
                adapter.getFilter().filter(s);
                return false;
            }
        });

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, majors);
        majorSpinner.setAdapter(adapter2);
        majorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedMajor = majors.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                selectedMajor = majors.get(0);
            }
        });

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ratings);
        ratingSpinner.setAdapter(adapter3);
        ratingSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedRating = ratings[i];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                selectedRating = ratings[0];
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SearchActivity.this, SearchFilterResultsActivity.class);
                String[] selectedFilters = {selectedMajor, selectedRating};
                intent.putExtra("Filters", selectedFilters);
                startActivity(intent);
            }
        });

    }
}